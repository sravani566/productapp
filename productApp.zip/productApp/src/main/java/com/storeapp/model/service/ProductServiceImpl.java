package com.storeapp.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.storeapp.entities.Product;
import com.storeapp.exceptions.ResourceNotFoundException;
import com.storeapp.model.repo.ProductRepo;
@Service
@Transactional
public class ProductServiceImpl implements ProductService{

	private ProductRepo productRepo;
	
	public ProductServiceImpl(ProductRepo productRepo) {
				this.productRepo = productRepo;
	}

	public Product getProductRepo(ProductRepo productId) {
		return productRepo.findById(productId).orElseThrow
				(()->new ResourceNotFoundException("product wit id:"+productId+" is not found"));
	}

	public void setProductRepo(ProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	@Override
	public Product getProductById(int productId) {
		return null;
	}

	@Override
	public Product getProductByProductName(String productName) {
		
		return null;
	}

	@Override
	public List<Product> getAllProduct() {
		return null;
	}

	@Override
	public Product addProduct(Product product) {
		
		return null;
	}

	@Override
	public Product updateProduct(int productId, Product product) {
		Product  productToUpdate=getProductById(productId);
		productToUpdate.setProductPrice(product.getProductPrice());
		productToUpdate.setProductDiscount(product.getProductDiscount());
		return productToUpdate;
	}

	@Override
	public Product deleteProduct(int productId) {
		return null;
	}

}
