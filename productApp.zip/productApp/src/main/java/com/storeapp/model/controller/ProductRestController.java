package com.storeapp.model.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.storeapp.entities.Product;
import com.storeapp.model.service.ProductService;

//REST
@RestController // = @controller + @ResponseBody
public class ProductRestController {
	
	private ProductService productService;
	
	@Autowired
	public ProductRestController(ProductService productService) {
		this.productService = productService;
	}

	@GetMapping(path="product" , produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Product> getAllProducts() {
		List<Product> products = productService.getAllProduct();
		return products;
	}
	
	@GetMapping(path="product/{id}" , produces = MediaType.APPLICATION_JSON_VALUE)
	public Product getProductById(@PathVariable(name = "id")int id) {
		return productService.getProductById(id);
	}
	
	//add
	@PostMapping(path="product", 
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public Product addProduct(@RequestBody Product product) {
		return productService.addProduct(product);
	}
	//update
	@PutMapping(path="product/{id}", 
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public Product updateProduct(@PathVariable(name = "id")int id,@RequestBody Product product ) {
		return productService.updateProduct(id, product);
	}
	//delete
	@DeleteMapping(path="product/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Product delProduct(@PathVariable(name = "id")int id) {
		return productService.deleteProduct(id);
	}
	
//	@GetMapping(path="product/{id}" , produces = MediaType.APPLICATION_JSON_VALUE)
//	public Product getProductById2(@PathVariable(name = "id")int id) {
//		Link link = linkTo(methodOn(ProductRestController.class).getProductById(id)).withSelfRel();
//		Product product = productService.getProductById(id);
//	    
//		return product;
//	}

//	private Object methodOn(Class<ProductRestController> class1) {
//		
//		return null;
//	}

}
