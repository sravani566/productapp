package com.storeapp.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name ="product_table")
public class Product {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "produceName", nullable = false, length = 100)
	private String produceName;
	@Column(name = "productPrice", nullable = false, length = 100)
	private double productPrice;
	
	@Column(name = "productDiscount", nullable = false, length = 100)
	private double productDiscount;
	@Column(name = "productCategory", nullable = false, length = 100)
	private String productCategory;
	@Column(name = "expiryDate", nullable = false)
	private LocalDate expiryDate;
	
	@Column(name = "product_quantity", nullable = false)
	private int productQuantity;
	
	
	
	public Product(String produceName, double productPrice, double productDiscount, String productCategory,
			LocalDate expiryDate, int productQuantity) {
		this.produceName = produceName;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productCategory = productCategory;
		this.expiryDate = expiryDate;
		this.productQuantity = productQuantity;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProduceName() {
		return produceName;
	}
	public void setProduceName(String produceName) {
		this.produceName = produceName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public double getProductDiscount() {
		return productDiscount;
	}
	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	

}
